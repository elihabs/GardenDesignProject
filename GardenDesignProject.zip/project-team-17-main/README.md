# CISC275-project-template

Note: for Github Actions to compile with gradle you must use the directory structure `src/main/java/` and `src/main/resources/`